import 'package:clapmi/core/app_variables.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_bloc.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_event.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_state.dart';
import 'package:custom_preload_videos/interface/controller_interface.dart';
import 'package:custom_preload_videos/my_custom_controller_impl/my_video_controller.dart';
import 'package:custom_preload_videos/preload_videos.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:video_player/video_player.dart';

class BragReels extends StatefulWidget {
  const BragReels({super.key});

  @override
  State<BragReels> createState() => _BragReelsState();
}

class _BragReelsState extends State<BragReels> {
  late PreloadVideos _preloadVideos;
  List<String> moreVideos = [];
  bool isMoreVideoSuccess = false;

  @override
  void initState() {
    super.initState();
    _preloadVideos = PreloadVideos(
      videoUrls: globalVideoUrls,
      preloadBackward: 4,
      preloadForward: 4,
      windowSize: 10,
      autoplayFirstVideo: true,
      paginationThreshold: 3,
      onPaginationNeeded: () async {
        print(
            "THIS IS TO CALL MORE PAGINATIONS ######@@@@@@@@@@########&&&&&&&&&&&&&&^^^^^^^^^^^^^^^^^");
        return [''];
      },
    );
  }

  Future<List<String>> fetchMoreVideos() async {
    print(
        "!!!!!!!!!!*********^^^^&&&&&&^^%%%%^^^^^%%THIS IS TO CALL THE GETCLAPMIVIDEOSEVENT CALLED HERE----");
    context.read<PostBloc>().add(GetClapmiVideosEvent());
    return moreVideos;
  }

  VideoPlayerController? _getVideoPlayerController(
      CustomVideoController? controller) {
    if (controller is DefaultVideoController) {
      return controller.videoPlayerController;
    }
  }

  @override
  void dispose() {
    _preloadVideos.disposeAll();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<PostBloc, PostState>(
        listener: (context, state) {
          if (state is VideosLoaded) {
            isMoreVideoSuccess = true;
            moreVideos = state.videoData.$2;
          }
        },
        builder: (context, state) {
          return SafeArea(
              child: PageView.builder(
                  itemCount: _preloadVideos.getTotalVideoCount(),
                  scrollDirection: Axis.vertical,
                  onPageChanged: (value) {
                    // if (_preloadVideos.getTotalVideoCount() - value == 3) {
                    //   fetchMoreVideos();
                    // }
                    _preloadVideos.scroll(value);
                  },
                  itemBuilder: (context, index) {
                    final controller =
                        _preloadVideos.getControllerAtIndex(index);
                    final videoPlayerController =
                        _getVideoPlayerController(controller);

                    // if (videoPlayerController == null) {
                    //   return Center(child: CircularProgressIndicator());
                    // }

                    return AspectRatio(
                      aspectRatio: videoPlayerController!.value.aspectRatio,
                      child: VideoPlayer(videoPlayerController),
                    );
                  }));
        },
      ),
    );
  }
}
