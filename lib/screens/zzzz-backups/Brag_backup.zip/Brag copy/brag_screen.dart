import 'dart:async';
import 'dart:ui';
import 'package:clapmi/Models/brag_model.dart';
import 'package:clapmi/core/app_variables.dart';
import 'package:clapmi/features/post/domain/entities/category_entity.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_bloc.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_event.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_state.dart';
import 'package:clapmi/features/wallet/domain/entities/gift_user.dart';
import 'package:clapmi/features/wallet/presentation/blocs/user_bloc/wallet_bloc.dart';
import 'package:clapmi/features/wallet/presentation/blocs/user_bloc/wallet_event.dart';
import 'package:clapmi/features/wallet/presentation/blocs/user_bloc/wallet_state.dart';
import 'package:clapmi/global_object_folder_jacket/global_object.dart';
import 'package:clapmi/screens/feed/feed_extraction_files/feed.dart';
import 'package:clapmi/screens/feed/feed_extraction_files/extraction.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:skeletonizer/skeletonizer.dart';
import 'package:video_player/video_player.dart';

// ═══════════════════════════════════════════════════════════════════════════
// OPTIMIZED VIDEO MANAGER - SINGLE PLAYING VIDEO AT A TIME
// ═══════════════════════════════════════════════════════════════════════════
class VideoManager {
  final Map<int, VideoPlayerController> _controllers = {};
  final Set<int> _initializingIndices = {};
  int? _currentPlayingIndex;

  // Only cache 2 videos: current + next
  static const int _cacheRadius = 1;
  static const Duration _initTimeout = Duration(seconds: 8);

  // ════════════════════════════════════════════════════════════════════════
  // CRITICAL: Smart prefetch - load current first, then adjacent
  // ════════════════════════════════════════════════════════════════════════
  Future<void> smartPrefetch(int centerIndex, List<String> videoUrls) async {
    if (videoUrls.isEmpty || centerIndex >= videoUrls.length) return;

    // Load current video with high priority
    if (!_controllers.containsKey(centerIndex) &&
        !_initializingIndices.contains(centerIndex)) {
      await _initializeVideo(centerIndex, videoUrls[centerIndex]);
    }

    // Load adjacent videos in background (non-blocking)
    _loadAdjacentVideos(centerIndex, videoUrls);
  }

  // ════════════════════════════════════════════════════════════════════════
  // Load next video (higher priority) then previous
  // ════════════════════════════════════════════════════════════════════════
  void _loadAdjacentVideos(int centerIndex, List<String> videoUrls) {
    Future.microtask(() async {
      // Load next video first (users scroll down more often)
      final nextIndex = centerIndex + 1;
      if (nextIndex < videoUrls.length &&
          !_controllers.containsKey(nextIndex) &&
          !_initializingIndices.contains(nextIndex)) {
        await _initializeVideo(nextIndex, videoUrls[nextIndex]);
      }

      // Small delay, then load previous
      await Future.delayed(const Duration(milliseconds: 200));

      final prevIndex = centerIndex - 1;
      if (prevIndex >= 0 &&
          !_controllers.containsKey(prevIndex) &&
          !_initializingIndices.contains(prevIndex)) {
        await _initializeVideo(prevIndex, videoUrls[prevIndex]);
      }
    });
  }

  // ════════════════════════════════════════════════════════════════════════
  // Initialize video with timeout protection
  // ════════════════════════════════════════════════════════════════════════
  Future<VideoPlayerController?> _initializeVideo(
      int index, String videoUrl) async {
    if (_initializingIndices.contains(index)) return null;
    if (_controllers.containsKey(index) &&
        _controllers[index]!.value.isInitialized) {
      return _controllers[index];
    }

    _initializingIndices.add(index);

    try {
      final controller = VideoPlayerController.networkUrl(
        Uri.parse(videoUrl),
        videoPlayerOptions: VideoPlayerOptions(
          mixWithOthers: false,
          allowBackgroundPlayback: false,
        ),
      );

      await controller.initialize().timeout(
        _initTimeout,
        onTimeout: () {
          debugPrint(
              '⚠️ Video $index timed out after ${_initTimeout.inSeconds}s');
          throw TimeoutException('Video initialization timeout');
        },
      );

      controller.setLooping(true);
      await controller.setVolume(0.0); // Start muted

      _controllers[index] = controller;
      debugPrint(
          '✅ Video $index ready (${controller.value.duration.inSeconds}s)');
      return controller;
    } catch (e) {
      debugPrint('❌ Video $index failed: $e');
      return null;
    } finally {
      _initializingIndices.remove(index);
    }
  }

  // ════════════════════════════════════════════════════════════════════════
  // CRITICAL FIX: Ensure ONLY ONE video plays at a time
  // ════════════════════════════════════════════════════════════════════════
  Future<void> switchToVideo(int index, {String? videoUrl}) async {
    // If already playing this video, do nothing
    if (_currentPlayingIndex == index) {
      final controller = _controllers[index];
      if (controller?.value.isInitialized == true &&
          !controller!.value.isPlaying) {
        await controller.setVolume(1.0);
        await controller.play();
      }
      return;
    }

    // CRITICAL: Pause and mute ALL other videos FIRST
    await _pauseAndMuteAllVideos();

    // Check if controller exists and is valid
    VideoPlayerController? controller = _controllers[index];

    // FIX: Reinitialize video if it was disposed or doesn't exist
    // First check if controller exists in map, then check if initialized
    if (controller == null) {
      // Controller was disposed completely, need to reinitialize
      if (videoUrl != null) {
        debugPrint('🔄 Reinitializing disposed video $index');
        final newController = await _initializeVideo(index, videoUrl);
        if (newController == null) {
          debugPrint('❌ Failed to reinitialize video $index');
          return;
        }
        controller = newController;
      } else {
        debugPrint('⚠️ No video URL provided for index $index');
        return;
      }
    } else {
      // Controller exists - check if it's initialized
      try {
        if (!controller.value.isInitialized) {
          // Controller exists but not initialized - reinitialize
          if (videoUrl != null) {
            debugPrint('🔄 Reinitializing uninitialized video $index');
            final newController = await _initializeVideo(index, videoUrl);
            if (newController == null) {
              debugPrint('❌ Failed to reinitialize video $index');
              return;
            }
            controller = newController;
          }
        }
      } catch (e) {
        // Controller was disposed - reinitialize
        debugPrint('⚠️ Controller for video $index was disposed: $e');
        if (videoUrl != null) {
          final newController = await _initializeVideo(index, videoUrl);
          if (newController == null) {
            debugPrint('❌ Failed to reinitialize video $index');
            return;
          }
          controller = newController;
        } else {
          debugPrint('⚠️ No video URL provided for index $index');
          return;
        }
      }
    }

    // Now play the target video
    if (controller.value.isInitialized) {
      _currentPlayingIndex = index;

      // Reset if near end
      if (controller.value.position > controller.value.duration * 0.95) {
        await controller.seekTo(Duration.zero);
      }

      await controller.setVolume(1.0);
      await controller.play();

      debugPrint('▶️ Playing video $index');
    }
  }

  // ════════════════════════════════════════════════════════════════════════
  // CRITICAL: Pause and mute ALL videos
  // ════════════════════════════════════════════════════════════════════════
  Future<void> _pauseAndMuteAllVideos() async {
    for (var entry in _controllers.entries) {
      if (entry.value.value.isInitialized) {
        await entry.value.pause();
        await entry.value.setVolume(0.0);
      }
    }
  }

  // ════════════════════════════════════════════════════════════════════════
  // Dispose videos far from current position
  // ════════════════════════════════════════════════════════════════════════
  void cleanupDistantVideos(int currentIndex) {
    final toRemove = <int>[];

    _controllers.forEach((index, controller) {
      if ((index - currentIndex).abs() > _cacheRadius + 2) {
        controller.dispose();
        toRemove.add(index);
        debugPrint('🗑️ Disposed video $index');
      }
    });

    toRemove.forEach(_controllers.remove);
  }

  VideoPlayerController? getController(int index) => _controllers[index];

  bool isInitialized(int index) =>
      _controllers[index]?.value.isInitialized == true;

  Future<void> pauseAll() async {
    await _pauseAndMuteAllVideos();
    _currentPlayingIndex = null;
  }

  void disposeAll() {
    for (var controller in _controllers.values) {
      controller.dispose();
    }
    _controllers.clear();
    _initializingIndices.clear();
    _currentPlayingIndex = null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// NETWORK MONITOR
// ═══════════════════════════════════════════════════════════════════════════
class NetworkMonitor {
  final _connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? _subscription;
  final ValueNotifier<bool> isOnline = ValueNotifier(true);

  void startMonitoring(Function(bool) onConnectionChange) {
    _checkInitialConnection();
    _subscription = _connectivity.onConnectivityChanged.listen((results) {
      final result =
          results.isNotEmpty ? results.first : ConnectivityResult.none;
      final online = result != ConnectivityResult.none;
      isOnline.value = online;
      onConnectionChange(online);
    });
  }

  Future<void> _checkInitialConnection() async {
    final results = await _connectivity.checkConnectivity();
    final result = results.isNotEmpty ? results.first : ConnectivityResult.none;
    isOnline.value = result != ConnectivityResult.none;
  }

  void dispose() {
    _subscription?.cancel();
    isOnline.dispose();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// MAIN SCREEN - OPTIMIZED
// ═══════════════════════════════════════════════════════════════════════════
class BragScreen extends StatefulWidget {
  const BragScreen({super.key});
  @override
  State<BragScreen> createState() => _BragScreenState();
}

class _BragScreenState extends State<BragScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  final VideoManager _videoManager = VideoManager();
  final NetworkMonitor _networkMonitor = NetworkMonitor();
  final PageController _pageController = PageController();

  List<BragModel> _brags = [];
  List<CategoryEntity> _categories = [];
  int _currentIndex = 0;
  int _currentTab = 1;
  bool _showCategories = false;
  bool _isFirstLoad = true;
  bool _isLoadingMore = false;

  @override
  void initState() {
    super.initState();
    _networkMonitor.startMonitoring(_onConnectionChanged);
    context.read<PostBloc>().add(GetAllVideoPostsEvent(isRefresh: true));
  }

  void _onConnectionChanged(bool isOnline) {
    if (!isOnline) {
      _showNetworkError();
    } else if (mounted) {
      ScaffoldMessenger.of(context).hideCurrentSnackBar();
    }
  }

  void _showNetworkError() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Row(
          children: [
            Icon(Icons.wifi_off, color: Colors.white),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'No internet connection. Videos may not load.',
                style: TextStyle(fontSize: 14),
              ),
            ),
          ],
        ),
        backgroundColor: Colors.red.shade700,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 4),
        action: SnackBarAction(
          label: 'Retry',
          textColor: Colors.white,
          onPressed: () {
            context
                .read<PostBloc>()
                .add(GetAllVideoPostsEvent(isRefresh: true));
          },
        ),
      ),
    );
  }

  // ════════════════════════════════════════════════════════════════════════
  // Smart prefetch with cleanup
  // ════════════════════════════════════════════════════════════════════════
  Future<void> _prefetchAround(int index) async {
    if (!_networkMonitor.isOnline.value) return;

    final videoUrls = _brags
        .map((b) => b.video?['url'] as String?)
        .where((url) => url != null)
        .cast<String>()
        .toList();

    if (videoUrls.isEmpty) return;

    await _videoManager.smartPrefetch(index, videoUrls);
    _videoManager.cleanupDistantVideos(index);

    if (mounted) setState(() {});
  }

  // ════════════════════════════════════════════════════════════════════════
  // CRITICAL: Handle page changes with proper video switching
  // ════════════════════════════════════════════════════════════════════════
  Future<void> _onPageChanged(int index) async {
    if (index == _currentIndex) return;

    _currentIndex = index;

    // Get video URL for potential reinitialization
    String? videoUrl;
    if (index < _brags.length) {
      videoUrl = _brags[index].video?['url'] as String?;
    }

    // CRITICAL: Switch video (this pauses all others automatically)
    await _videoManager.switchToVideo(index, videoUrl: videoUrl);

    // Prefetch adjacent videos in background
    unawaited(_prefetchAround(index));

    // CRITICAL: Load more posts when near the end
    if (index >= _brags.length - 3 && !_isLoadingMore) {
      _loadMorePosts();
    }

    if (mounted) setState(() {});
  }

  // ════════════════════════════════════════════════════════════════════════
  // Load more posts
  // ════════════════════════════════════════════════════════════════════════
  void _loadMorePosts() {
    if (_isLoadingMore) return;

    _isLoadingMore = true;
    context.read<PostBloc>().add(GetAllVideoPostsEvent(isRefresh: false));

    debugPrint('📥 Loading more posts...');
  }

  // ════════════════════════════════════════════════════════════════════════
  // Initialize first video immediately
  // ════════════════════════════════════════════════════════════════════════
  Future<void> _initializeFirstVideo() async {
    if (_brags.isEmpty) return;

    final videoUrls = _brags
        .map((b) => b.video?['url'] as String?)
        .where((url) => url != null)
        .cast<String>()
        .toList();

    if (videoUrls.isEmpty) return;

    // Load and play first video
    await _videoManager.smartPrefetch(0, videoUrls);
    await _videoManager.switchToVideo(0,
        videoUrl: videoUrls.isNotEmpty ? videoUrls[0] : null);

    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            BlocConsumer<PostBloc, PostState>(
              listener: _handleBlocState,
              builder: (context, state) {
                if (state is GetAllVideoPostsLoadingState && _isFirstLoad) {
                  return _buildSkeletonLoader();
                }
                if (state is GetAllVideoPostsErrorState) {
                  return _buildErrorState(state.errorMessage);
                }
                if (_currentTab != 1) {
                  _videoManager.pauseAll();
                }
                return _buildContent();
              },
            ),
            _buildNetworkIndicator(),
          ],
        ),
      ),
    );
  }

  void _handleBlocState(BuildContext context, PostState state) async {
    if (state is GetCategoriesLoadingState ||
        state is GetCategoriesSuccessState) {
      await _videoManager.pauseAll();
      if (state is GetCategoriesSuccessState) {
        _showCategories = true;
        _categories = state.listOfCategoryEntity;
      }
    }

    if (state is GetAllVideoPostsSuccessState) {
      if (state.isRefresh) {
        // Full refresh
        _brags = state.posts.map((e) => BragModel.fromPostModel(e)).toList();
        _videoManager.disposeAll();
        _currentIndex = 0;

        if (_pageController.hasClients) {
          _pageController.jumpToPage(0);
        }
      } else {
        // Append new posts
        _brags.addAll(state.posts.map((e) => BragModel.fromPostModel(e)));
      }

      _isLoadingMore = false;
      _isFirstLoad = false;

      // Initialize first video if needed
      if (state.isRefresh) {
        unawaited(_initializeFirstVideo());
      }

      if (mounted) setState(() {});
    }

    if (state is CurrentTabIndexState) {
      _currentTab = state.index;
    }
  }

  Widget _buildContent() {
    if (_brags.isEmpty) {
      return const Center(
        child: Text(
          'Loading....',
          style: TextStyle(fontSize: 16, color: Colors.grey),
        ),
      );
    }

    return Stack(
      children: [
        Visibility(
          visible: !_showCategories,
          replacement: _buildCategories(),
          child: PageView.builder(
            itemCount: _brags.length,
            controller: _pageController,
            scrollDirection: Axis.vertical,
            physics: const BouncingScrollPhysics(
              parent: AlwaysScrollableScrollPhysics(),
            ),
            onPageChanged: _onPageChanged,
            itemBuilder: (context, index) {
              final controller = _videoManager.getController(index);

              if (controller == null || !_videoManager.isInitialized(index)) {
                return _buildVideoPlaceholder(index);
              }

              return _buildVideoItem(controller, _brags[index], index);
            },
          ),
        ),
        _buildTopControls(),
      ],
    );
  }

  Widget _buildVideoItem(
      VideoPlayerController? controller, BragModel brag, int index) {
    // Defensive check: if controller is null or not initialized, show placeholder
    if (controller == null) {
      return _buildVideoPlaceholder(index);
    }

    // Check if controller is still valid (not disposed)
    try {
      if (!controller.value.isInitialized) {
        return _buildVideoPlaceholder(index);
      }
    } catch (e) {
      // Controller was disposed
      return _buildVideoPlaceholder(index);
    }

    return GestureDetector(
      onTap: () {
        if (controller.value.isPlaying) {
          controller.pause();
        } else {
          controller.play();
        }
        setState(() {});
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          Center(
            child: AspectRatio(
              aspectRatio: controller.value.aspectRatio,
              child: VideoPlayer(controller),
            ),
          ),
          if (controller.value.isBuffering)
            const Center(
              child: CircularProgressIndicator(
                strokeWidth: 3,
                valueColor: AlwaysStoppedAnimation(Colors.white),
              ),
            ),
          Positioned(
            left: 10,
            right: 10,
            bottom: 20,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(child: _buildVideoInfo(brag)),
                const SizedBox(width: 10),
                _buildActions(brag, index),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoInfo(BragModel brag) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildUserNugget(brag),
        const SizedBox(height: 10),
        if (brag.content?.isNotEmpty == true)
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.black26,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              brag.content!,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                shadows: [
                  Shadow(
                      offset: Offset(0, 1),
                      blurRadius: 4,
                      color: Colors.black54),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildActions(BragModel brag, int index) {
    return SizedBox(
      height: 320,
      child: ReactionPanelVertical(
        model: brag,
        updateModel: (updated) {
          _brags[index] = updated;
          if (mounted) setState(() {});
        },
        updatePostClappCount: (postInfo) {
          _brags[index].clapCount = int.tryParse(
              postInfo.claps ?? _brags[index].clapCount.toString());
        },
        updatePostCommentCount: (count) {
          _brags[index].commentCount = int.tryParse(count);
        },
        updatePostSharedCount: (_) {},
      ),
    );
  }

  Widget _buildVideoPlaceholder(int index) {
    return Container(
      color: Colors.black,
      child: Stack(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(
                  width: 50,
                  height: 50,
                  child: CircularProgressIndicator(
                    strokeWidth: 4,
                    valueColor: AlwaysStoppedAnimation(Colors.blue),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  _networkMonitor.isOnline.value
                      ? 'Loading video...'
                      : 'No connection',
                  style: const TextStyle(color: Colors.white70, fontSize: 16),
                ),
              ],
            ),
          ),
          if (index < _brags.length)
            Positioned(
              left: 10,
              right: 10,
              bottom: 20,
              child: _buildVideoInfo(_brags[index]),
            ),
        ],
      ),
    );
  }

  Widget _buildNetworkIndicator() {
    return ValueListenableBuilder<bool>(
      valueListenable: _networkMonitor.isOnline,
      builder: (context, isOnline, _) {
        if (isOnline) return const SizedBox.shrink();

        return Positioned(
          top: 10,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.red.shade700,
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.wifi_off, color: Colors.white, size: 16),
                  SizedBox(width: 8),
                  Text('No connection',
                      style: TextStyle(color: Colors.white, fontSize: 12)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTopControls() {
    return Positioned(
      top: 8,
      left: 0,
      right: 0,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.only(bottom: 70),
          child: AllFollowingCategoriesSelectorWidget(
            indexchangingFunction: (text) {
              if (text.toLowerCase().contains("categories")) {
                _videoManager.pauseAll();
                context.read<PostBloc>().add(GetCategoriesEvent());
              } else {
                _showCategories = false;
              }
              if (mounted) setState(() {});
            },
          ),
        ),
      ),
    );
  }

  Widget _buildUserNugget(BragModel brag) {
    return GestureDetector(
      onTap: () {
        _videoManager.pauseAll();
        context.read<PostBloc>().add(GetCurrentTabIndexEvent(index: 6));

        if (brag.author == profileModelG?.pid) {
          context.pushNamed(MyAppRouteConstant.myAccountPage);
        } else {
          context.pushNamed(
            MyAppRouteConstant.othersAccountPage,
            extra: {"userId": brag.author},
          );
        }
      },
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.black26,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              clipBehavior: Clip.hardEdge,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: getFigmaColor("006FCD"),
              ),
              height: 32.w,
              width: 32.w,
              child: _buildProfileImage(brag.authorImage),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  brag.authorName ?? "N/A",
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                Text(
                  brag.humanReadableDate ?? "N/A",
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileImage(String? imageUrl) {
    if (imageUrl == null || imageUrl.isEmpty) {
      return const Icon(Icons.person, color: Colors.white);
    }

    if (imageUrl.toLowerCase().endsWith('.svg')) {
      return const Icon(Icons.person, color: Colors.white);
    }

    return Image.network(
      imageUrl,
      fit: BoxFit.cover,
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return const Center(child: CircularProgressIndicator(strokeWidth: 2));
      },
      errorBuilder: (_, __, ___) =>
          const Icon(Icons.person, color: Colors.white),
    );
  }

  Widget _buildCategories() {
    return SingleChildScrollView(
      child: Container(
        padding: const EdgeInsets.only(top: 80, left: 12, right: 12),
        color: getFigmaColor('070707'),
        child: Column(
          children:
              _categories.map((cat) => _buildCategorySlab(cat.name!)).toList(),
        ),
      ),
    );
  }

  Widget _buildCategorySlab(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Container(
        height: 100,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: getFigmaColor("464747")),
          color: getFigmaColor("181919"),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title, style: const TextStyle(fontSize: 25)),
            const Icon(Icons.category_outlined),
          ],
        ),
      ),
    );
  }

  Widget _buildSkeletonLoader() {
    return Skeletonizer(
      effect: PulseEffect(from: Colors.grey[600]!, to: Colors.grey[100]!),
      child: Container(color: Colors.black),
    );
  }

  Widget _buildErrorState(String error) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, size: 64, color: Colors.red),
          const SizedBox(height: 16),
          const Text(
            'Failed to load videos',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(
              error,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.grey),
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              context
                  .read<PostBloc>()
                  .add(GetAllVideoPostsEvent(isRefresh: true));
            },
            icon: const Icon(Icons.refresh),
            label: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _videoManager.disposeAll();
    _networkMonitor.dispose();
    _pageController.dispose();
    super.dispose();
  }
}

//THIS WIDGET IS FOR FOLLOWING CATEGORIES
//THIS WIDGET IS FOR FOLLOWING CATEGORIES
class AllFollowingCategoriesSelectorWidget extends StatefulWidget {
  final Function(String) indexchangingFunction;
  const AllFollowingCategoriesSelectorWidget(
      {super.key, required this.indexchangingFunction});

  @override
  State<AllFollowingCategoriesSelectorWidget> createState() =>
      _AllFollowingCategoriesSelectorWidgetState();
}

class _AllFollowingCategoriesSelectorWidgetState
    extends State<AllFollowingCategoriesSelectorWidget> {
  int selectedIndex = 1;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 196,
      height: 54,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        color: const Color(0xFF2D3748), // Dark background like in image
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
            child: InkWell(
              onTap: () {
                setState(() {
                  selectedIndex = 1;
                });
                widget.indexchangingFunction("All");
              },
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(999),
                  color:
                      (selectedIndex == 1) ? Colors.white : Colors.transparent,
                ),
                child: Text(
                  "All",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: (selectedIndex == 1) ? Colors.black : Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: InkWell(
              onTap: () {
                setState(() {
                  selectedIndex = 2;
                });
                widget.indexchangingFunction("Following");
              },
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(999),
                  color:
                      (selectedIndex == 2) ? Colors.white : Colors.transparent,
                ),
                child: Text(
                  "Following",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: (selectedIndex == 2) ? Colors.black : Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class CommentBoxforBrag extends StatefulWidget {
  const CommentBoxforBrag({super.key});

  @override
  State<CommentBoxforBrag> createState() => _CommentBoxforBragState();
}

class _CommentBoxforBragState extends State<CommentBoxforBrag> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: List.generate(
        5,
        (index) => const CommentWidgetForBrag(),
      ),
    );
  }
}

class CommentWidgetForBrag extends StatelessWidget {
  const CommentWidgetForBrag({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Divider(),
        _buildTopBar(),
        const SizedBox(height: 10),
        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            "This just made my day 🔥😂",
          ),
        ),
        const SizedBox(height: 20),
        ReactionPanelHorizontal()
      ],
    );
  }

  SizedBox _buildTopBar() {
    return SizedBox(
      height: 50,
      child: Row(
        children: [
          Container(
            decoration: const BoxDecoration(shape: BoxShape.circle),
            height: 32,
            width: 32,
            child: Image.asset("assets/icons/Frame 1000002049.png"),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Zuri Jackson",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              Text(
                "21hr",
                style: TextStyle(color: getFigmaColor("B5B5B5")),
              ),
            ],
          ),
          const SizedBox(width: 10),
          Align(
            alignment: Alignment.topCenter,
            child: Image.asset("assets/icons/Vector (11).png"),
          ),
          const Expanded(child: SizedBox()),
          IconButton(onPressed: () {}, icon: const Icon(Icons.more_horiz))
        ],
      ),
    );
  }
}

void showBottomBragSheet(BuildContext context, String creatorId) {
  final passwordCtrl = TextEditingController();
  final amountCtrl = TextEditingController();
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (BuildContext context) {
      return BlocConsumer<WalletBloc, WalletState>(
        listener: (context, state) {
          if (state is GiftUserErrorState) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.errorMessage)),
            );
          }
          if (state is GiftUserSuccessState) {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(state.message),
            ));
          }
        },
        builder: (context, state) {
          return Padding(
            padding: EdgeInsets.only(
              top: 20.h,
              left: 20.w,
              right: 20.w,
              bottom: MediaQuery.of(context).viewInsets.bottom,
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Center(
                    child: Text(
                      "GiftCapcoin",
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(height: 15.h),
                  Center(
                    child: Column(
                      children: [
                        Text(
                          "Select Team",
                          style: TextStyle(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.white24),
                        ),
                        SizedBox(height: 15.h),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                height: 40.h, // Reduced height
                                width: 140.w, // Increased width
                                decoration: BoxDecoration(
                                  color: getFigmaColor("006FCD", 27),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: const Center(
                                  child: Text(
                                    "Team Blue",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 15.w),
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                height: 40.h, // Reduced height
                                width: 140.w, // Increased width
                                decoration: BoxDecoration(
                                  color: Colors.red,
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: const Center(
                                  child: Text(
                                    "Team Red",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20.h),
                  Text(
                    "Select Debit Wallet",
                    style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white24),
                  ),
                  SizedBox(height: 15.h),
                  DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      filled: true,

                      fillColor: const Color(0xFF181919), // Background color
                      hintText: "t",
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius:
                            BorderRadius.circular(20), // Border radius 20
                      ),
                    ),
                    value: null, // Default value
                    items: const [
                      DropdownMenuItem(
                        value: "web3",
                        child: Text("Web 3 Wallet"),
                      ),
                      DropdownMenuItem(
                        value: "clapmi",
                        child: Text("Clapmi Wallet"),
                      ),
                    ],
                    onChanged: (value) {},
                  ),
                  SizedBox(height: 20.h),
                  Text(
                    "Amount",
                    style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white24),
                  ),
                  SizedBox(height: 15.h),
                  TextFormField(
                    controller: amountCtrl,
                    decoration: InputDecoration(
                      hintText: "20,000",
                      prefixIcon: const Icon(Icons.monetization_on,
                          color: Colors.orange),
                      filled: true,
                      fillColor: const Color(0xFF181919), // Background color
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius:
                            BorderRadius.circular(20), // Border radius 20
                      ),
                    ),
                  ),
                  SizedBox(height: 20.h),
                  Text(
                    "Account Password",
                    style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.white24),
                  ),
                  SizedBox(height: 15.h),
                  TextFormField(
                    controller: passwordCtrl,
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: "************",
                      filled: true,
                      fillColor: const Color(0xFF181919), // Background color
                      border: OutlineInputBorder(
                        borderSide: BorderSide.none,
                        borderRadius:
                            BorderRadius.circular(20), // Border radius 20
                      ),
                    ),
                  ),
                  SizedBox(height: 25.h),
                  Center(
                    child: GestureDetector(
                      onTap: () {
                        final giftEntity = GiftUserEntity(
                          to: creatorId,
                          amount: int.tryParse(amountCtrl.text) ?? 0,
                          password: passwordCtrl.text,
                          type: 'standard',
                        );

                        context.read<WalletBloc>().add(GiftUserEvent(
                            giftClapPointRequestEntity: giftEntity));
                        //  Navigator.pop(context); // Close bottom sheet
                      },
                      child: Container(
                        width: 300.w, // Made button longer
                        padding: EdgeInsets.symmetric(vertical: 14.h),
                        decoration: BoxDecoration(
                          color: Colors.blue, // Blue color for the gift button
                          borderRadius:
                              BorderRadius.circular(20), // Border radius 20
                        ),
                        child: const Center(
                          child: Text(
                            "Gift",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 15.h),
                ],
              ),
            ),
          );
        },
      );
    },
  );
}

class BragWidget extends StatefulWidget {
  final Widget? image;
  final BragModel bragModel;

  const BragWidget({super.key, this.image, required this.bragModel});

  @override
  State<BragWidget> createState() => _BragWidgetState();
}

class _BragWidgetState extends State<BragWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildTopBar(),
        SizedBox(
          height: MediaQuery.of(context).size.height * .8,
          child: Stack(
            children: [
              widget.image ??
                  Image.asset(
                    "assets/icons/anime-boy 1 (1).png",
                    fit: BoxFit.cover,
                    height: double.infinity,
                    width: double.infinity,
                  ),
              Align(
                alignment: Alignment.bottomRight,
                child: SizedBox(
                  width: 90,
                  height: 250,
                  child: ReactionPanelVertical(
                    model: widget.bragModel,
                    updateModel: (bragModel) {
                      if (mounted) setState(() {});
                    },
                  ),
                ),
              ),
              const Align(
                  alignment: Alignment.bottomLeft, child: Text("24k Views")),
            ],
          ),
        ),
        Container(
          height: 60,
          width: double.infinity,
          color: AppColors.backgroundColor,
          child: const Text("Lorem Ipsum is simply dummy text of more... "),
        ),
      ],
    );
  }

  SizedBox _buildTopBar() {
    return SizedBox(
      height: 50,
      child: Row(
        children: [
          Container(
            decoration: const BoxDecoration(shape: BoxShape.circle),
            height: 32,
            width: 32,
            child: Image.asset("assets/icons/Frame 1000002049.png"),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Zuri Jackson",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              Text(
                "21hr",
                style: TextStyle(color: getFigmaColor("B5B5B5")),
              ),
            ],
          ),
          const SizedBox(width: 10),
          Align(
            alignment: Alignment.center,
            child: Image.asset("assets/icons/Vector (11).png"),
          ),
          const SizedBox(width: 10),
          Align(
            child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: getFigmaColor("DF7C08")),
              height: 32,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: const Text(
                "upcoming",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                ),
              ),
            ),
          ),
          const Expanded(child: SizedBox()),
          IconButton(onPressed: () {}, icon: const Icon(Icons.more_horiz))
        ],
      ),
    );
  }
}
