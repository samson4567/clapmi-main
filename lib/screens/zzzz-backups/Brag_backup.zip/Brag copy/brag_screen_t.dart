import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:flutter_video_caching/flutter_video_caching.dart';

class CachedVideoScreen extends StatefulWidget {
  final String url;
  final Function(Player thePlayer) storePlayerForPausePlay;

  const CachedVideoScreen(
      {super.key, required this.url, required this.storePlayerForPausePlay});

  @override
  State<CachedVideoScreen> createState() => _CachedVideoScreenState();
}

class _CachedVideoScreenState extends State<CachedVideoScreen> {
  late final Player player = Player();
  late final VideoController controller = VideoController(player);

  @override
  void initState() {
    super.initState();
    // player = Player();
    _setupVideo().then(
      (value) {
        if (mounted) setState(() {});
      },
    );
  }

// const rawUrl = 'https://example.com/video.mp4';
  Future<void> _setupVideo() async {
    // 3. Convert the remote URL to a Proxy URL
    // This starts the "Play and Cache" process automatically
    final proxyUri = widget.url.toLocalUri();

    // 4. Open in MediaKit
    await player.open(Media(proxyUri.toString()));
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("MediaKit + Proxy Cache")),
      body: Center(
        child: Video(controller: controller),
      ),
    );
  }
}
