import 'dart:io';
import 'dart:math';
import 'package:clapmi/Models/brag_model.dart';
import 'package:clapmi/core/app_variables.dart';
import 'package:clapmi/features/chats_and_socials/domain/entities/chat_user.dart';
import 'package:clapmi/features/chats_and_socials/presentation/blocs/user_bloc/chats_and_socials_bloc.dart';
import 'package:clapmi/features/chats_and_socials/presentation/blocs/user_bloc/chats_and_socials_state.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_bloc.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_event.dart';
import 'package:clapmi/features/post/presentation/blocs/user_bloc/post_state.dart';
import 'package:clapmi/global_object_folder_jacket/global_widgets/global_widgets.dart';
import 'package:clapmi/global_object_folder_jacket/routes/api_route.config.dart';
import 'package:clapmi/screens/Brag/brag_screen.dart';
import 'package:clapmi/screens/Brag/brag_util.dart';
import 'package:clapmi/screens/BragVideoErrorAttemptRepairBackupFolder/brag_util.dart';
import 'package:clapmi/screens/challenge/challenge_list.dart';
import 'package:clapmi/screens/feed/feed_extraction_files/extraction.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';
import 'package:video_player/video_player.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

class BragScreenTuTu extends StatefulWidget {
  const BragScreenTuTu({super.key});

  @override
  State<BragScreenTuTu> createState() => BragScreenTuTuState();
}

class BragScreenTuTuState extends State<BragScreenTuTu> with RouteAware {
  PageController thePageController = PageController();
  bool isthereInternet = true;
  StreamSubscription? internetSubscription;

  @override
  void didChangeDependencies() {
    routeObserver.subscribe(this, ModalRoute.of(context)!);
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    routeObserver.unsubscribe(this);
    internetSubscription?.cancel();

    // FIXED: Properly dispose all video controllers when leaving the page
    BragPageVideoIitialisationController().disposeAll();

    super.dispose();
  }

  @override
  void didPop() {
    // FIXED: Pause all videos when popping this route
    BragPageVideoIitialisationController().pauseAll();
    super.didPop();
  }

  @override
  void didPopNext() {
    // FIXED: Resume current video when returning to this page
    try {
      BragPageVideoIitialisationController()
          .theDisplayedListOfBragAndVideoModel[
              BragPageVideoIitialisationController().currentIndex]
          .theVideoPlayerController
          ?.play();
    } catch (e) {}
    super.didPopNext();
  }

  @override
  void didPush() {
    // FIXED: Pause all videos when pushing a new route
    BragPageVideoIitialisationController().pauseAll();
    super.didPush();
  }

  @override
  void didPushNext() {
    // FIXED: Pause all videos when a new route is pushed on top
    BragPageVideoIitialisationController().pauseAll();
    super.didPushNext();
  }

  @override
  initState() {
    internetSubscription =
        InternetConnection().onStatusChange.listen((InternetStatus status) {
      if (status == InternetStatus.connected) {
        setState(() {
          isthereInternet = true;
        });
      } else {
        isthereInternet = false;
      }
    });

    super.initState();
    // context.read<ChatsAndSocialsBloc>().add(GetClappersEvent());
  }

  settAppropriatePlayingInndex() {
    int countitit = 0;

    try {
      BragPageVideoIitialisationController()
          .theDisplayedListOfBragAndVideoModel[
              BragPageVideoIitialisationController().currentIndex - 1]
          .theVideoPlayerController
          ?.pause();
    } catch (e) {}
    try {
      BragPageVideoIitialisationController()
          .theDisplayedListOfBragAndVideoModel[
              BragPageVideoIitialisationController().currentIndex + 1]
          .theVideoPlayerController
          ?.pause();
    } catch (e) {}
    try {
      BragPageVideoIitialisationController()
          .theDisplayedListOfBragAndVideoModel[
              BragPageVideoIitialisationController().currentIndex]
          .theVideoPlayerController
          ?.play();
    } catch (e) {}
  }

  loadMoreIfItIsTime() {
    if (BragPageVideoIitialisationController()
                    .theDisplayedListOfBragAndVideoModel
                    .length -
                BragPageVideoIitialisationController().currentIndex <
            5 &&
        !BragPageVideoIitialisationController()
            .fetchedpages
            .contains(BragPageVideoIitialisationController().pageNumber)) {
      context
          .read<PostBloc>()
          .add(GetAllVideoPostsEvent(isRefresh: true, index: 0));
      BragPageVideoIitialisationController()
          .fetchedpages
          .add(BragPageVideoIitialisationController().pageNumber);
    }
  }

  bool loadingMore = false;
  List<ChatUser> friends = [];

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ChatsAndSocialsBloc, ChatsAndSocialsState>(
        listener: (context, state) {
      if (state is ClappersLoaded) {
        setState(() {
          friends = state.friends;
        });
      }
    }, builder: (context, _) {
      return BlocConsumer<PostBloc, PostState>(listener: (context, state) {
        if (state is GetAllVideoPostsLoadingState) {
          print("shdvhjdasdhvdvsahjdshd");
          loadingMore = true;
        } else {
          loadingMore = false;
        }
        if (state is GetAllVideoPostsSuccessState) {
          BragPageVideoIitialisationController()
              .theListOfBragAndVideoModelAll
              .addAll(state.posts
                  .map(
                    (e) => BragModel.fromPostModel(e),
                  )
                  .map(
                    (e) => BragAndVideoModel(
                        bragModel: e,
                        videoUrl: e.postVideoUrls!.first,
                        modelPageNumber:
                            BragPageVideoIitialisationController().pageNumber +
                                1),
                  )
                  .toList());
          BragPageVideoIitialisationController()
              .changeDisplayedList(showFollowing, friends: friends);
          BragPageVideoIitialisationController().pageNumber += 1;
        }

        if (state is GetAllVideoPostsErrorState) {
          BragPageVideoIitialisationController()
              .fetchedpages
              .remove(BragPageVideoIitialisationController().pageNumber);
        }
      }, builder: (context, s) {
        return Stack(
          children: [
            Column(
              children: [
                Expanded(
                  child: Builder(builder: (context) {
                    return (BragPageVideoIitialisationController()
                            .theDisplayedListOfBragAndVideoModel
                            .isEmpty)
                        ? Center(
                            child: Text(
                              "No Brags Yet",
                              style: TextStyle(fontSize: 18),
                            ),
                          )
                        : PageView.builder(
                            controller: thePageController,
                            scrollDirection: Axis.vertical,
                            itemBuilder: (context, index) => _buildBragWidget(
                              index,
                            ),
                            onPageChanged: (value) {
                              BragPageVideoIitialisationController()
                                  .theDisplayedListOfBragAndVideoModel[
                                      BragPageVideoIitialisationController()
                                          .currentIndex]
                                  .theVideoPlayerController
                                  ?.pause();
                              videoPlayerControllerG =
                                  BragPageVideoIitialisationController()
                                      .theDisplayedListOfBragAndVideoModel[
                                          BragPageVideoIitialisationController()
                                              .currentIndex]
                                      .theVideoPlayerController;
                              BragPageVideoIitialisationController()
                                  .currentIndex = value;

                              // settAppropriatePlayingInndex();
                              loadMoreIfItIsTime();
                              setState(() {});
                            },
                            itemCount: BragPageVideoIitialisationController()
                                .theDisplayedListOfBragAndVideoModel
                                .length,
                          );
                  }),
                ),
                if (loadingMore)
                  Center(
                    child: CircularProgressIndicator.adaptive(),
                  )
              ],
            ),
            _buildTopControls(),
            if (!isthereInternet)
              Positioned.fill(
                child: AbsorbPointer(
                  absorbing: true,
                  child: Container(
                    decoration:
                        BoxDecoration(color: Colors.black.withAlpha(150)),
                    child: Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            "There is no Internet connection",
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 18.sp,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Poppins'),
                          ),
                          Text(
                            "Reconnecting...",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                                fontSize: 18.sp,
                                fontFamily: 'Poppins'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              )
          ],
        );
      });
    });
  }

  VideoPlayerController? controller;

  _buildBragWidget(
    int index,
  ) {
    BragAndVideoModel bEnVMdoel = BragPageVideoIitialisationController()
        .theDisplayedListOfBragAndVideoModel[index];

    return FancyContainer(
      action: () async {
        bEnVMdoel.theVideoPlayerController!.value.isPlaying
            ? await bEnVMdoel.theVideoPlayerController?.pause()
            : await bEnVMdoel.theVideoPlayerController?.play();
        print(
            "djfdfkgdjfdkjf>>${bEnVMdoel.theVideoPlayerController!.value.isPlaying}");
        // setState(() {});
      },
      child: Stack(
        children: [
          _theVideoWidgetGangan(index, bEnVMdoel),
          Positioned(
            left: 10,
            right: 10,
            bottom: 20,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(child: _buildVideoInfo(bEnVMdoel.bragModel)),
                const SizedBox(width: 10),
                _buildActions(bEnVMdoel, index),
              ],
            ),
          ),
        ],
      ),
    );
  }

  FutureBuilder<String> _theVideoWidgetGangan(
      int index, BragAndVideoModel bEnVMdoel) {
    print("djbfbdskfbdjfbsdkfbsdkfbdskjfbdsf${Random().nextInt(10000)}");
    return FutureBuilder<String>(
        future: () async {
          await BragPageVideoIitialisationController()
              .preinitializeFuturevideos(
                  BragPageVideoIitialisationController().currentIndex);

          settAppropriatePlayingInndex();

          if (index == 0) await bEnVMdoel.theVideoPlayerController?.play();
          if (index != BragPageVideoIitialisationController().currentIndex) {
            await bEnVMdoel.theVideoPlayerController?.pause();
          }
          currentlyDisplayedVideoPlayerController =
              BragPageVideoIitialisationController()
                  .theDisplayedListOfBragAndVideoModel[
                      BragPageVideoIitialisationController().currentIndex]
                  .theVideoPlayerController;
          return "";
        }.call(),
        builder: (context, asyncSnapshot) {
          if (asyncSnapshot.hasData) {
            try {
              return Center(
                child: AspectRatio(
                  aspectRatio:
                      bEnVMdoel.theVideoPlayerController!.value.aspectRatio,
                  child: VideoPlayer(bEnVMdoel.theVideoPlayerController!),
                ),
              );
            } catch (e) {
              bEnVMdoel.theVideoPlayerController = null;
              try {
                setState(() {});
              } catch (e) {}
            }
          }
          return Center(
            child: Center(
              child: FancyContainer(
                action: () async {},
                child: SizedBox.square(
                  dimension: 100,
                  child: Image.asset("assets/icons/IconLogoBetter.png"),
                )
                    .animate(
                      onComplete: (controller) {
                        controller.repeat();
                      },
                    )
                    .fadeIn(duration: 1.seconds)
                    .then()
                    .fadeOut(duration: 1.seconds),
              ),
            ),
          );
        });
  }

  Widget _buildActions(BragAndVideoModel theBragAndVideoModel, int index) {
    return SizedBox(
      height: 320,
      child: ReactionPanelVertical(
        model: theBragAndVideoModel.bragModel,
        updateModel: (updated) {
          theBragAndVideoModel.bragModel = updated;
          if (mounted) setState(() {});
        },
        updatePostClappCount: (postInfo) {
          theBragAndVideoModel.bragModel.clapCount = int.tryParse(
              postInfo.claps ??
                  theBragAndVideoModel.bragModel.clapCount.toString());
        },
        updatePostCommentCount: (count) {
          theBragAndVideoModel.bragModel.commentCount = int.tryParse(count);
        },
        updatePostSharedCount: (_) {},
      ),
    );
  }

  Widget _buildProfileImage(String? imageUrl) {
    if (imageUrl == null || imageUrl.isEmpty) {
      return const Icon(Icons.person, color: Colors.white);
    }

    if (imageUrl.toLowerCase().endsWith('.svg')) {
      return const Icon(Icons.person, color: Colors.white);
    }

    return Image.network(
      imageUrl,
      fit: BoxFit.cover,
      loadingBuilder: (context, child, progress) {
        if (progress == null) return child;
        return const Center(child: CircularProgressIndicator(strokeWidth: 2));
      },
      errorBuilder: (_, __, ___) =>
          const Icon(Icons.person, color: Colors.white),
    );
  }

  Widget _buildUserNugget(BragModel brag) {
    return GestureDetector(
      onTap: () {
        BragPageVideoIitialisationController().pauseAll();
        context.read<PostBloc>().add(GetCurrentTabIndexEvent(index: 6));

        if (brag.author == profileModelG?.pid) {
          context.pushNamed(MyAppRouteConstant.myAccountPage);
        } else {
          context.pushNamed(
            MyAppRouteConstant.othersAccountPage,
            extra: {"userId": brag.author},
          );
        }
      },
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.black26,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              clipBehavior: Clip.hardEdge,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: getFigmaColor("006FCD"),
              ),
              height: 32.w,
              width: 32.w,
              child: _buildProfileImage(brag.authorImage),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  brag.authorName ?? "N/A",
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
                Text(
                  brag.humanReadableDate ?? "N/A",
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoInfo(BragModel brag) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildUserNugget(brag),
        const SizedBox(height: 10),
        if (brag.content?.isNotEmpty == true)
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.black26,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              brag.content!,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                shadows: [
                  Shadow(
                      offset: Offset(0, 1),
                      blurRadius: 4,
                      color: Colors.black54),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildTopControls() {
    return Positioned(
      top: 8,
      left: 0,
      right: 0,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.only(bottom: 70),
          child: AllFollowingCategoriesSelectorWidget(
            indexchangingFunction: (text) {
              showFollowing = text.toLowerCase().contains("follow");
              BragPageVideoIitialisationController()
                  .changeDisplayedList(showFollowing, friends: friends);
              if (mounted) setState(() {});
            },
          ),
        ),
      ),
    );
  }

  List<BragAndVideoModel> theDisplayedListOfBragAndVideoModel = [];
  bool showFollowing = false;
}
